import * as turf from '@turf/turf';

/**
 * EdgeBuilder - Constructs edges between nodes using visibility graph algorithm
 * Ensures edges don't pass through walls or obstacles
 */
export class EdgeBuilder {
    constructor(collisionDetector) {
        this.collisionDetector = collisionDetector;
    }

    /**
     * Build edges for all nodes on a floor using visibility graph
     * OPTIMIZED: Uses spatial partitioning for O(n log n) instead of O(n²)
     */
    async buildEdgesForFloor(nodes, floorId, maxDistance = 15, spatialIndex = null, maxNeighbors = null, yieldEvery = null) {
        const edges = [];
        console.log(`Building edges for floor ${floorId} with ${nodes.length} nodes (maxDist: ${maxDistance}m)...`);

        // Convert maxDistance to approximate degrees (rough conversion for spatial queries)
        const maxDistDegrees = maxDistance / 111320; // ~1 degree = 111km

        // For each node, only check nearby nodes
        for (let index = 0; index < nodes.length; index++) {
            const nodeA = nodes[index];
            const [lng, lat] = nodeA.coords;

            // Get candidate neighbors from spatial query or nearby filter
            let candidates;
            if (spatialIndex && spatialIndex.quadTree) {
                // Use QuadTree for fast neighbor lookup
                const range = {
                    minX: lng - maxDistDegrees,
                    minY: lat - maxDistDegrees,
                    maxX: lng + maxDistDegrees,
                    maxY: lat + maxDistDegrees
                };
                candidates = spatialIndex.quadTree.query(range);
            } else {
                // Fallback: filter by bounding box
                candidates = nodes.filter(n => {
                    const [nLng, nLat] = n.coords;
                    return Math.abs(nLng - lng) <= maxDistDegrees &&
                        Math.abs(nLat - lat) <= maxDistDegrees;
                });
            }

            // Optionally limit neighbors to the nearest N candidates to reduce edge count
            if (maxNeighbors && candidates.length > maxNeighbors) {
                candidates = candidates
                    .map(candidate => {
                        const [cLng, cLat] = candidate.coords;
                        const dx = cLng - lng;
                        const dy = cLat - lat;
                        return { candidate, distSq: dx * dx + dy * dy };
                    })
                    .sort((a, b) => a.distSq - b.distSq)
                    .slice(0, maxNeighbors)
                    .map(item => item.candidate);
            }

            for (const nodeB of candidates) {
                // Skip self and already-processed pairs
                if (nodeB.id <= nodeA.id) continue;

                // Calculate distance
                const distance = this.calculateDistance(nodeA.coords, nodeB.coords);

                // Skip if too far (exact check)
                if (distance > maxDistance) continue;

                // Check line-of-sight
                if (this.hasLineOfSight(nodeA.coords, nodeB.coords, floorId)) {
                    // Add bidirectional edge
                    edges.push({
                        from: nodeA.id,
                        to: nodeB.id,
                        weight: distance,
                        type: 'walkable'
                    });
                    edges.push({
                        from: nodeB.id,
                        to: nodeA.id,
                        weight: distance,
                        type: 'walkable'
                    });
                }
            }

            if (yieldEvery && index % yieldEvery === 0) {
                await new Promise(resolve => setTimeout(resolve, 0));
            }
        }

        console.log(`  Created ${edges.length} edges`);
        return edges;
    }

    /**
     * Check if two points have line-of-sight (no obstacles between them)
     */
    hasLineOfSight(coordsA, coordsB, floorId) {
        return this.collisionDetector.isPathClear(coordsA, coordsB, floorId);
    }

    /**
     * Calculate Euclidean distance between two points
     */
    calculateDistance(coordsA, coordsB) {
        try {
            return turf.distance(
                turf.point(coordsA),
                turf.point(coordsB),
                { units: 'meters' }
            );
        } catch (e) {
            // Fallback to simple Euclidean distance
            const [lng1, lat1] = coordsA;
            const [lng2, lat2] = coordsB;
            const dx = lng2 - lng1;
            const dy = lat2 - lat1;
            return Math.sqrt(dx * dx + dy * dy) * 111320; // Rough meters conversion
        }
    }

    /**
     * Build all edges for a graph
     */
    async buildAllEdges(graph, maxDistance = 15, maxNeighbors = null, yieldEvery = null) {
        let totalEdges = 0;

        // Get all floors
        const floors = new Set();
        graph.nodes.forEach(node => floors.add(node.floorId));

        // Build edges for each floor
        for (const floorId of floors) {
            const nodesOnFloor = graph.getNodesOnFloor(floorId);
            const spatialData = graph.spatialIndex.get(floorId);
            const edges = await this.buildEdgesForFloor(
                nodesOnFloor,
                floorId,
                maxDistance,
                spatialData,
                maxNeighbors,
                yieldEvery
            );

            // Add edges to graph
            edges.forEach(edge => {
                graph.addEdge(edge.from, edge.to, edge.weight, {
                    type: edge.type
                });
            });

            totalEdges += edges.length;
        }

        console.log(`Total edges built: ${totalEdges}`);
        return totalEdges;
    }
}
