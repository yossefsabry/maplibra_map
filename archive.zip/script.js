import { Map as MapLibreMap, NavigationControl } from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { starlightTheme } from './theme.js';
import { loadMVFBundle } from './src/mvf-loader.js';
import { LayerManager } from './src/layer-manager.js';
import { UIManager } from './src/ui-manager.js';
import { LegendToggleManager } from './src/legend-toggle-manager.js';

const idle = () => new Promise(resolve => {
  if (typeof window !== 'undefined' && 'requestIdleCallback' in window) {
    window.requestIdleCallback(resolve, { timeout: 200 });
  } else {
    setTimeout(resolve, 0);
  }
});

const fetchJson = async (url) => {
  const response = await fetch(url);
  if (!response.ok) {
    return null;
  }
  return response.json();
};


async function initApp() {
  // 1. Load Data
  const mvfAssetRoot = '/assets';
  const mvfData = await loadMVFBundle(`${mvfAssetRoot}/my_data.zip`);
  const { manifest, styles, locations, floors, entranceIds, entranceGeometryToFloorMap, geometry } = mvfData;

  const mapTitle = document.getElementById('map-title');
  if (mapTitle && manifest?.properties?.name) {
    mapTitle.textContent = manifest.properties.name;
  }

  const backButton = document.getElementById('back-button');
  if (backButton) {
    backButton.addEventListener('click', () => {
      window.history.back();
    });
  }

  // 2. Initialize Map
  const center = manifest.features?.[0]?.geometry?.coordinates || [0, 0];
  const themeColors = starlightTheme.colors;

  const map = new MapLibreMap({
    container: 'map',
    style: starlightTheme.mapStyle,
    center: center,
    zoom: 19,
    pitch: 60,
    bearing: -17,
    minZoom: 15,
    maxPitch: 85,
    antialias: true // Important for smooth edges
  });

  map.addControl(new NavigationControl(), 'top-right');

  // 3. Customize Basemap to match theme.js colors
  map.on('style.load', () => {
    const layers = map.getStyle().layers;
    layers.forEach(layer => {
      if (layer.type === 'background') {
        map.setPaintProperty(layer.id, 'background-color', themeColors.background);
      }
      if (layer.id.includes('water') && layer.type === 'fill') {
        map.setPaintProperty(layer.id, 'fill-color', themeColors.Restrooms);
      }
      if (layer.id.includes('road') || layer.id.includes('transportation')) {
        if (layer.type === 'line') {
          // Major roads: orange
          if (layer.id.includes('major') || layer.id.includes('primary') || layer.id.includes('trunk') || layer.id.includes('motorway')) {
            map.setPaintProperty(layer.id, 'line-color', '#D97706');
            map.setPaintProperty(layer.id, 'line-opacity', 0.8);
          }
          // Minor roads: dark gray
          else {
            map.setPaintProperty(layer.id, 'line-color', '#2A2D35');
            map.setPaintProperty(layer.id, 'line-opacity', 0.6);
          }
        }
      }
      if (layer.id.includes('building')) {
        map.setLayoutProperty(layer.id, 'visibility', 'none');
      }
    });
  });

  map.on('load', async () => {
    // 4. Setup Managers
    const layerManager = new LayerManager(map, themeColors);

    // 5. Render Layers
    layerManager.addBuildingShell(floors);
    layerManager.processStyles(styles, geometry, entranceIds);
    layerManager.addDoors(geometry, entranceIds, entranceGeometryToFloorMap);
    layerManager.addLabels(locations, geometry);

    // 5a. Load and display building address
    try {
      const response = await fetch(`${mvfAssetRoot}/address.json`);
      if (response.ok) {
        const addressData = await response.json();
        const addressDisplay = document.getElementById('map-address');
        if (addressDisplay && addressData.primary?.display?.displayAddress) {
          addressDisplay.textContent = addressData.primary.display.displayAddress;
        }
      }
    } catch (e) {
      console.warn('Failed to load building address:', e);
    }

    // 6. Setup UI
    const uiManager = new UIManager(map, layerManager, floors);
    uiManager.init();

    // 6b. Setup Search Bar
    import('./src/ui/SearchBox.js').then(({ SearchBox }) => {
      const searchBox = new SearchBox(map, layerManager, locations, floors);
      searchBox.init();
    });

    // 7. Setup Legend Toggle (with localStorage persistence)
    const legendToggleManager = new LegendToggleManager(layerManager);
    legendToggleManager.init();

    const layersToggle = document.getElementById('layers-toggle');
    const legendPanel = document.getElementById('developer-legend');
    if (layersToggle && legendPanel) {
      layersToggle.addEventListener('click', () => {
        const isOpen = legendPanel.classList.toggle('is-open');
        layersToggle.classList.toggle('is-active', isOpen);
      });

      document.addEventListener('click', (event) => {
        if (!legendPanel.contains(event.target) && !layersToggle.contains(event.target)) {
          legendPanel.classList.remove('is-open');
          layersToggle.classList.remove('is-active');
        }
      });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
          legendPanel.classList.remove('is-open');
          layersToggle.classList.remove('is-active');
        }
      });
    }

    const debugLayerLoaders = [
      {
        layerId: 'wall-nodes-layer',
        url: '/assets/wall_nodes.geojson',
        add: (data) => layerManager.addWallNodes(data)
      },
      {
        layerId: 'stairs-nodes-layer',
        url: '/assets/stairs_nodes.geojson',
        add: (data) => layerManager.addStairsNodes(data)
      },
      {
        layerId: 'elevator-nodes-layer',
        url: '/assets/elevator_nodes.geojson',
        add: (data) => layerManager.addElevatorNodes(data)
      },
      {
        layerId: 'annotation-nodes-layer',
        url: '/assets/annotation_nodes.geojson',
        add: (data) => layerManager.addAnnotationNodes(data)
      },
      {
        layerId: 'walkable-nodes-layer',
        url: '/assets/walkable_nodes.geojson',
        add: (data) => layerManager.addWalkableNodes(data)
      },
      {
        layerId: 'walkable-areas-layer',
        url: '/assets/walkable_areas.geojson',
        add: (data) => layerManager.addWalkableAreas(data)
      },
      {
        layerId: 'nonwalkable-nodes-layer',
        url: '/assets/nonwalkable_nodes.geojson',
        add: (data) => layerManager.addNonwalkableNodes(data)
      },
      {
        layerId: 'kinds-nodes-layer',
        url: '/assets/kinds_nodes.geojson',
        add: (data) => layerManager.addKindsNodes(data)
      },
      {
        layerId: 'entrance-aesthetic-nodes-layer',
        url: '/assets/entrance_aesthetic_nodes.geojson',
        add: (data) => layerManager.addEntranceAestheticNodes(data)
      },
      {
        layerId: 'location-markers-layer',
        url: '/assets/location_markers.geojson',
        add: (data) => layerManager.addLocationMarkers(data)
      }
    ];

    const loadDebugLayers = async () => {
      for (const loader of debugLayerLoaders) {
        await idle();
        try {
          const data = await fetchJson(loader.url);
          if (!data) {
            console.warn(`Failed to load ${loader.url}`);
            continue;
          }
          await loader.add(data);
          const isVisible = legendToggleManager.getLayerState(loader.layerId);
          layerManager.setLayerVisibility(loader.layerId, isVisible);
        } catch (e) {
          console.error(`Error loading ${loader.url}:`, e);
        }
      }
    };

    // Defer heavy debug layer loading to keep initial map responsive
    setTimeout(() => {
      loadDebugLayers();
    }, 0);
  });
}

initApp().catch(console.error);
