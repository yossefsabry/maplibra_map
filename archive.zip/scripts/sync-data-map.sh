#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SRC_DIR="$ROOT_DIR/data_map"
DST_DIR="$ROOT_DIR/maplibra_web/assets"

if [[ ! -d "$SRC_DIR" ]]; then
  echo "Missing data_map at $SRC_DIR" >&2
  exit 1
fi

mkdir -p "$DST_DIR"

# Sync raw MVF content (keep derived node geojsons already in assets)
rsync -a --exclude 'temp_mvf' "$SRC_DIR"/ "$DST_DIR"/

# Rebuild the MVF bundle zip from the source directory
(
  cd "$SRC_DIR"
  zip -qr "$DST_DIR/my_data.zip" .
)

echo "Synced data_map -> maplibra_web/assets and rebuilt my_data.zip"
